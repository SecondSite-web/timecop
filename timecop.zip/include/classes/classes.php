<?php

require_once ROOT_PATH .'include/classes/Install.php';
require_once ROOT_PATH .'include/classes/DashSetup.php';
require_once ROOT_PATH .'include/classes/DashAuth.php';
require_once ROOT_PATH .'include/classes/DashSettings.php';
require_once ROOT_PATH .'include/classes/Permissions.php';
require_once ROOT_PATH .'include/classes/DashNonce.php';
require_once ROOT_PATH .'include/classes/CustomStore.php';
require_once ROOT_PATH .'include/classes/Encryption.php';

require_once ROOT_PATH .'include/classes/Companies.php';
require_once ROOT_PATH .'include/classes/timer/Tasks.php';

